Ten pinned Erdos proofs from plby/lean-proofs. Original author/license notices are preserved.

With elan installed, run `lake exe cache get` then `lake build ErdosProblems.Erdos399` (replace 399 with another included number). For memory-constrained computers, build one proof at a time.

See manifest.json for source hashes and verification.json for actual local Lean compiler output.
Walkthrough: https://erdos-proof-playground.vercel.app/
Repository: https://github.com/lorem111/erdos-proof-playground
